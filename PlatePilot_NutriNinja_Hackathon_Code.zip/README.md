# PlatePilot: NutriNinja Cup

## Run locally
1. Install Node.js (LTS) from https://nodejs.org/
2. Extract this folder.
3. Open a terminal in this folder.
4. Run `npm install`
5. Run `npm start`
6. Open http://localhost:3000

## Project structure
- `server.js`: Express API and budget-aware meal selection/swap logic
- `data/recipes.json`: sample Indian student-friendly recipes
- `public/index.html`: application layout
- `public/style.css`: responsive styling
- `public/app.js`: frontend interactions and Chart.js visualization

## Hackathon notes
This is a working prototype using illustrative recipe costs and nutrition estimates. Update `data/recipes.json` with locally verified prices, portion sizes and nutrition data before presenting it as factual. The greedy selection is a demo heuristic, not a clinical diet recommendation. Individual energy and nutrient needs vary; consult a qualified nutrition professional for personalized targets. The sample weekly list repeats the selected day seven times; a future version can generate a varied seven-day plan.
