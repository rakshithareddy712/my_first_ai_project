const express = require("express");
const path = require("path");
const recipes = require("./data/recipes.json");
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function matchesDiet(recipe, diet) {
  if (diet === "Vegan") return recipe.type === "Vegan";
  if (diet === "Vegetarian") return recipe.type === "Vegetarian" || recipe.type === "Vegan";
  return true;
}
function score(recipe, goal) {
  const proteinPerRupee = recipe.protein / Math.max(recipe.cost, 1);
  if (goal === "Muscle Gain") return proteinPerRupee * 3 + recipe.protein * 0.15;
  if (goal === "Weight Loss") return recipe.protein * 0.8 + recipe.fiber * 0.5 - recipe.calories * 0.001;
  return recipe.protein * 0.5 + recipe.fiber * 0.25;
}
function generatePlan({budget, diet, goal}) {
  const slots = ["Breakfast", "Lunch", "Snack", "Dinner"];
  const pools = slots.map(slot => recipes.filter(r => r.meal === slot && matchesDiet(r, diet))
    .sort((a,b) => score(b, goal)-score(a, goal)));
  let selected = [], remaining = Number(budget);
  // Greedy selection with a minimum spend reserve for later meal slots.
  for (let i=0; i<slots.length; i++) {
    const laterMin = pools.slice(i+1).reduce((sum,p) => sum + Math.min(...p.map(r=>r.cost)), 0);
    const pick = pools[i].find(r => r.cost <= remaining - laterMin) || pools[i].find(r => r.cost <= remaining);
    if (!pick) throw new Error(`Budget too low to fill ${slots[i]}. Try increasing your daily budget.`);
    selected.push({...pick});
    remaining -= pick.cost;
  }
  return selected;
}
app.get("/api/recipes", (req,res) => res.json(recipes));
app.post("/api/plan", (req,res) => {
  const {budget, diet="Vegetarian", goal="Maintenance"} = req.body;
  if (!Number.isFinite(Number(budget)) || Number(budget) < 50) return res.status(400).json({error:"Please enter a daily budget of at least ₹50."});
  try {
    const meals = generatePlan({budget:Number(budget), diet, goal});
    res.json({meals, total:meals.reduce((s,m)=>s+m.cost,0), budget:Number(budget)});
  } catch(e) { res.status(400).json({error:e.message}); }
});
app.post("/api/swap", (req,res) => {
  const {mealId, currentIds=[], budgetLeft=1000, diet="Vegetarian", goal="Maintenance"} = req.body;
  const current = recipes.find(r=>r.id===mealId);
  if (!current) return res.status(404).json({error:"Meal not found."});
  const alternative = recipes.filter(r=>r.meal===current.meal && r.id!==mealId &&
    !currentIds.includes(r.id) && matchesDiet(r,diet) && r.cost<=budgetLeft)
    .sort((a,b)=>score(b,goal)-score(a,goal))[0];
  if (!alternative) return res.status(404).json({error:"No suitable alternative fits the remaining budget."});
  res.json(alternative);
});
app.post("/api/grocery", (req,res) => {
  const meals = req.body.meals || [];
  const items = {};
  meals.forEach(meal => (meal.ingredients||[]).forEach(item => {
    items[item.name] = (items[item.name] || 0) + item.qty;
  }));
  const list = Object.entries(items).map(([name,qty])=>({name,qty,weeklyQty:qty*7,category:/rice|roti|oats|bread/i.test(name)?"Grains":/egg|soya|dal|chana|paneer|curd|milk/i.test(name)?"Protein & Dairy":"Produce & Other"}));
  res.json({list, weeklyCost:meals.reduce((s,m)=>s+m.cost,0)*7});
});
const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log(`PlatePilot running at http://localhost:${PORT}`));