let currentPlan=[], chart;
const $=id=>document.getElementById(id);
$("profileForm").addEventListener("submit", async e=>{
 e.preventDefault(); $("error").textContent="";
 try{
  const res=await fetch("/api/plan",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({budget:Number($("budget").value),diet:$("diet").value,goal:$("goal").value})});
  const data=await res.json(); if(!res.ok) throw new Error(data.error);
  currentPlan=data.meals; render(data);
 }catch(err){$("error").textContent=err.message;}
});
function totals(){return currentPlan.reduce((a,m)=>{["calories","protein","carbs","fat"].forEach(k=>a[k]+=m[k]);a.cost+=m.cost;return a},{calories:0,protein:0,carbs:0,fat:0,cost:0});}
function render(data){
 $("results").classList.remove("hidden"); $("budgetPill").textContent=`₹${data.total} / ₹${data.budget}`;
 const t=totals();
 $("stats").innerHTML=[["Estimated calories",`${t.calories} kcal`],["Protein",`${t.protein} g`],["Carbohydrates",`${t.carbs} g`],["Fat",`${t.fat} g`]].map(([a,b])=>`<div class="stat"><small>${a}</small><strong>${b}</strong></div>`).join("");
 $("mealGrid").innerHTML=currentPlan.map(m=>`<article class="meal"><div class="meal-top"><div><div class="eyebrow">${m.meal.toUpperCase()}</div><h3>${m.name}</h3></div><div class="cost">₹${m.cost}</div></div><div class="meal-meta">⏱ ${m.time} min • ${m.type}</div><div class="macroline"><span>🔥 ${m.calories} kcal</span><span>💪 ${m.protein}g protein</span><span>🍚 ${m.carbs}g carbs</span><span>🥑 ${m.fat}g fat</span></div><details><summary>Ingredients & simple instructions</summary><p><b>Ingredients:</b> ${m.ingredients.map(x=>`${x.name} (${x.qty})`).join(", ")}</p><ol>${m.steps.map(s=>`<li>${s}</li>`).join("")}</ol></details><button class="swap" onclick="swapMeal('${m.id}')">↻ Swap ${m.meal}</button></article>`).join("");
 drawChart(t); loadGroceries();
}
function drawChart(t){
 const ctx=$("macroChart"); if(chart)chart.destroy();
 chart=new Chart(ctx,{type:"doughnut",data:{labels:["Protein","Carbs","Fat"],datasets:[{data:[t.protein*4,t.carbs*4,t.fat*9],backgroundColor:["#1d7652","#d9a441","#a6c96a"],borderWidth:0}]},options:{cutout:"65%",plugins:{legend:{position:"bottom"},tooltip:{callbacks:{label:c=>`${c.label}: ${Math.round(c.raw)} kcal`}}}}});
}
async function swapMeal(id){
 const old=currentPlan.find(m=>m.id===id), used=currentPlan.filter(m=>m.id!==id).map(m=>m.id);
 const budgetLeft=Number($("budget").value)-currentPlan.reduce((s,m)=>s+m.cost,0)+old.cost;
 const res=await fetch("/api/swap",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mealId:id,currentIds:used,budgetLeft,diet:$("diet").value,goal:$("goal").value})});
 const data=await res.json(); if(!res.ok){alert(data.error);return;}
 currentPlan=currentPlan.map(m=>m.id===id?data:m); render({total:totals().cost,budget:Number($("budget").value)});
}
async function loadGroceries(){
 const res=await fetch("/api/grocery",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({meals:currentPlan})});
 const data=await res.json();
 $("groceryList").innerHTML=`<p class="muted">Estimated 7-day spend if this same day is repeated: <b>₹${data.weeklyCost}</b></p>`+data.list.map(x=>`<div class="grocery-item"><span>${x.name} <small>· ${x.category}</small></span><b>${x.weeklyQty} units/week</b></div>`).join("");
}
$("printBtn").addEventListener("click",()=>window.print());